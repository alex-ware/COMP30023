#include "detect.h"

int main(int argc, char *argv[]) {
    //invoke(argc, argv);    
    //printf("bruh\n");
    read_file(get_path(argc, argv));  
    return 0;
}

int invoke(int argc, char *argv[]) {
    //int i = 0;

    //for (i = 0; i < argc; i++) {
    //    printf("%s\n", argv[i]);
    //}
    return 0;
}

char* get_path(int argc, char *argv[]) {
    int path_length = 0;

    for (int i = 0; i < argc; i++) {
        if (strcmp(argv[i], "-f") == 0) {
            //makeprintf("found\n");
            path_length = strlen(argv[i+1]);
            char *file_path = (char *)malloc(sizeof(char)*path_length);
            strcpy(file_path, argv[i+1]);
            //printf("path_length = %d\n", path_length);
            //printf("file_path = %s\n", file_path);
            return file_path;
        }
    }
    return "0";
}

int read_file(char* file_path) {
    char c;
    int i = 0;
    int processes = 0, conts = 0;
    FILE *fp = fopen(file_path,"r");
    c = fgetc(fp);

    //printf("name jeff");
    char *file_conts = (char *)malloc(sizeof(char)*(conts+1));
    //printf("name jeff");

    while (c != EOF) { 
        if (conts >= 1) {
            file_conts = (char *)realloc(file_conts, sizeof(char)*(conts+1)); 
        }

        if (isdigit(c)!=0) {
            file_conts[conts] = c;
            //printf("%c", file_conts[conts]);
            conts++;
        }
        if (c == '\n') {
            file_conts[conts] = c;
            //printf("%c", file_conts[conts]);
            conts++;
            processes++;
        }
        c = getc(fp);
        i++;
    }

    /*for(i=0; i<conts; i++) {
        printf("%d", file_conts[i]);
    }*/
    free(file_conts);

    
    printf("Processes %d\nFiles  %d\n", processes, conts-(processes*2));
    fclose(fp);
    return 0;
}

